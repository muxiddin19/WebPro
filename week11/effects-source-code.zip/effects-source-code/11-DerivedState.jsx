import { useState, useEffect, useRef } from 'react';

// Unnecessary effect: extra state and an extra render
function WithEffect({ first, last }) {
  const renders = useRef(0); renders.current += 1;   // demo counter only
  const [fullName, setFullName] = useState('');
  useEffect(() => { setFullName(first + ' ' + last); }, [first, last]);
  return <p>WithEffect: {fullName} (renders: {renders.current})</p>;
}

// Better: derive the value while rendering
function Derived({ first, last }) {
  const renders = useRef(0); renders.current += 1;   // demo counter only
  const fullName = first + ' ' + last;
  return <p>Derived: {fullName} (renders: {renders.current})</p>;
}

export default function Demo() {
  const [first, setFirst] = useState('Kim');
  const [last, setLast]   = useState('Minho');
  return (
    <div>
      <input value={first} onChange={e => setFirst(e.target.value)} />
      <input value={last}  onChange={e => setLast(e.target.value)} />
      <WithEffect first={first} last={last} />
      <Derived first={first} last={last} />
    </div>
  );
}
