import { useState, useEffect } from 'react';

export function UserProfile({ userId }) {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetch(`https://api.example.com/users/${userId}`)
      .then(res => {
        if (!res.ok) throw new Error('User not found');
        return res.json();
      })
      .then(data => { setUser(data); setLoading(false); })
      .catch(err  => { setError(err.message); setLoading(false); });
  }, [userId]);       // re-fetch when userId prop changes

  if (loading) return <p>Loading...</p>;
  if (error)   return <p>Error: {error}</p>;
  return <h2>{user?.name}</h2>;
}

// Demo wrapper: change the userId prop
export default function Demo() {
  const [id, setId] = useState(1);
  return (
    <div>
      {[1, 2, 3, 99].map(n => (
        <button key={n} onClick={() => setId(n)}>userId {n}</button>
      ))}
      <UserProfile userId={id} />
    </div>
  );
}
