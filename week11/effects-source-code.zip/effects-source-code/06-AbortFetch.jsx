import { useState, useEffect } from 'react';

export function UserCard({ username }) {
  const [user, setUser]   = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    setError(null);

    async function fetchUser() {
      try {
        const res = await fetch(
          `https://api.github.com/users/${username}`,
          { signal: controller.signal }   // link to controller
        );
        if (!res.ok) throw new Error('User not found');
        const data = await res.json();
        setUser(data);
      } catch (err) {
        if (err.name === 'AbortError') {            // ignore cancelled requests
          console.log('aborted request for', username);
          return;
        }
        setError(err.message);
      }
    }
    fetchUser();

    // Cancel the in-flight request if username changes
    return () => controller.abort();
  }, [username]);

  if (error) return <p>Error: {error}</p>;
  return <p>{user ? user.login + ' / ' + user.name : 'Loading...'}</p>;
}

// Demo wrapper: type to change the username
export default function Demo() {
  const [name, setName] = useState('react-learner');
  return (
    <div>
      <input value={name} onChange={e => setName(e.target.value)} />
      <UserCard username={name} />
    </div>
  );
}
