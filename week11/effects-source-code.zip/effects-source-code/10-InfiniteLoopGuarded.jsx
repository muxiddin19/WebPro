import { useState, useEffect, useRef } from 'react';

// BAD: setState inside the effect + that same state in the dependency array
function BadLoop() {
  const [count, setCount] = useState(0);
  const runs = useRef(0);

  useEffect(() => {
    runs.current += 1;
    // Safety guard so this demo cannot freeze the page
    if (runs.current > 8) { console.log('safety stop: this loop would never end'); return; }
    console.log('effect run #' + runs.current + ', count =', count);
    setCount(count + 1);          // changes count -> effect runs again
  }, [count]);

  return <p>BadLoop count = {count}</p>;
}

// FIX: functional update with an empty dependency array
function FixedOnce() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    setCount(c => c + 1);
    console.log('FixedOnce effect ran');
  }, []);

  return <p>FixedOnce count = {count}</p>;
}

// Demo wrapper
export default function Demo() {
  const [which, setWhich] = useState('none');
  return (
    <div>
      <button onClick={() => setWhich('bad')}>Run BadLoop</button>
      <button onClick={() => setWhich('fixed')}>Run FixedOnce</button>
      <button onClick={() => setWhich('none')}>Unmount</button>
      {which === 'bad'   && <BadLoop />}
      {which === 'fixed' && <FixedOnce />}
    </div>
  );
}
