import { useState, useEffect } from 'react';

// In this demo, requests for SHORTER names are slower, so responses
// arrive out of order when you type quickly.
export default function RaceCondition() {
  const [query, setQuery]   = useState('');
  const [result, setResult] = useState('');
  const [safe, setSafe]     = useState(false);

  useEffect(() => {
    if (!query) return;
    const controller = new AbortController();

    fetch(`https://api.github.com/users/${query}`,
          { signal: safe ? controller.signal : undefined })
      .then(res => res.json())
      .then(data => setResult(data.login))
      .catch(err => { if (err.name !== 'AbortError') console.log(err.message); });

    // SAFE mode: cancel the previous request when query changes
    return safe ? () => controller.abort() : undefined;
  }, [query, safe]);

  return (
    <div>
      <label>
        <input type="checkbox" checked={safe} onChange={e => setSafe(e.target.checked)} />
        {' '}Abort previous request (the fix)
      </label>
      <p><input value={query} placeholder="type slowly, then quickly: abcdef"
                onChange={e => setQuery(e.target.value)} /></p>
      <p>You typed: <b>{query || '-'}</b></p>
      <p>Result shown for: <b style={{ color: result && result !== query ? 'crimson' : 'inherit' }}>
        {result || '-'}</b> {result && result !== query && ' (stale!)'}</p>
    </div>
  );
}
