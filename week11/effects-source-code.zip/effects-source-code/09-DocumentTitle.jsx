import { useState, useEffect } from 'react';

export default function Inbox() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    document.title = `Inbox (${count})`;
    console.log('document.title is now', document.title);
  }, [count]);

  return (
    <div>
      <p>Unread messages: {count}</p>
      <button onClick={() => setCount(c => c + 1)}>New message</button>
      <button onClick={() => setCount(0)}>Mark all read</button>
    </div>
  );
}
