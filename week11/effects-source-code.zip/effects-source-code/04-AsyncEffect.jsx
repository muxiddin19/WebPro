import { useState, useEffect } from 'react';

export default function AsyncEffect() {
  const [user, setUser]       = useState(null);
  const [error, setError]     = useState(null);
  const [loading, setLoading] = useState(true);

  // WRONG: useEffect(async () => { ... }, [])
  //   an async callback returns a Promise, but useEffect
  //   expects undefined or a cleanup function

  // CORRECT: define the async function inside and call it
  useEffect(() => {
    async function fetchData() {
      try {
        const res  = await fetch('https://api.github.com/users/muxiddin19');
        const data = await res.json();
        setUser(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
    // No return needed here unless we have cleanup
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error)   return <p>Error: {error}</p>;
  return <p>{user.login}: {user.name}</p>;
}
