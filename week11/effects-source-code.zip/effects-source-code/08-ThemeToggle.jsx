import { useState, useEffect } from 'react';

export default function ThemeToggle() {
  // Read once at mount (lazy initializer form)
  const [theme, setTheme] = useState(
    () => localStorage.getItem('theme') || 'light'
  );

  // Write whenever theme changes
  useEffect(() => {
    localStorage.setItem('theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  return (
    <button onClick={() => setTheme(t => t === 'light' ? 'dark' : 'light')}>
      Current: {theme} — Click to toggle
    </button>
  );
}
