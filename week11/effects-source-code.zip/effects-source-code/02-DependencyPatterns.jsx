import { useState, useEffect } from 'react';

function RunsOnce() {
  useEffect(() => { console.log('[]     -> ran once after mount'); }, []);
  return <p>[] : once after mount</p>;
}

function RunsOnChange({ val }) {
  useEffect(() => { console.log('[val]  -> ran, val =', val); }, [val]);
  return <p>[val] : when val changes</p>;
}

function RunsEveryRender() {
  // No dependency array: usually a bug
  useEffect(() => { console.log('(none) -> ran after EVERY render'); });
  return <p>(none) : after every render</p>;
}

export default function DependencyPatterns() {
  const [val, setVal]   = useState(0);
  const [tick, setTick] = useState(0);
  return (
    <div>
      <button onClick={() => setVal(v => v + 1)}>val++ (changes val)</button>
      <button onClick={() => setTick(t => t + 1)}>re-render (val unchanged)</button>
      <p>val = {val}, extra renders = {tick}</p>
      <RunsOnce />
      <RunsOnChange val={val} />
      <RunsEveryRender />
    </div>
  );
}
