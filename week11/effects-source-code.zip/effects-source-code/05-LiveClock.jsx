import { useState, useEffect } from 'react';

function LiveClock() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const intervalId = setInterval(() => {
      setTime(new Date());
    }, 1000);

    // CORRECT: return cleanup, stop the timer when the component unmounts
    return () => clearInterval(intervalId);
  }, []);    // empty: start once on mount, cleanup on unmount

  return <p>{time.toLocaleTimeString('ko-KR')}</p>;
}

// WRONG: no cleanup. The interval keeps running after unmount.
// (This copy stops itself after 10 ticks so the demo stays safe.)
function LeakyClock() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    let n = 0;
    const id = setInterval(() => {
      console.log('leaky tick #' + (++n) + ' (component may already be gone)');
      setTime(new Date());
      if (n >= 10) clearInterval(id);
    }, 1000);
  }, []);

  return <p>{time.toLocaleTimeString('ko-KR')}</p>;
}

// Demo wrapper
export default function Demo() {
  const [mode, setMode] = useState('none');
  return (
    <div>
      <button onClick={() => setMode('good')}>Mount LiveClock</button>
      <button onClick={() => setMode('leaky')}>Mount LeakyClock</button>
      <button onClick={() => setMode('none')}>Unmount</button>
      {mode === 'good'  && <LiveClock />}
      {mode === 'leaky' && <LeakyClock />}
    </div>
  );
}
