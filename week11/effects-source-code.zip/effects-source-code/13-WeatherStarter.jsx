import { useState, useEffect } from 'react';

// Homework starter: Weather Dashboard (Open-Meteo, no API key)
// TODO 1: let the user type a CITY name and look up coordinates
//         (https://geocoding-api.open-meteo.com/v1/search?name=Seoul)
// TODO 2: map weather_code to a description ("Clear", "Rain", ...)
// TODO 3: BONUS: use navigator.geolocation for the first coordinates
export default function WeatherStarter() {
  const [lat, setLat]         = useState(37.46);
  const [lon, setLon]         = useState(127.01);
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true); setError(null);

    const url = 'https://api.open-meteo.com/v1/forecast'
      + `?latitude=${lat}&longitude=${lon}`
      + '&current=temperature_2m,wind_speed_10m,weather_code';

    fetch(url, { signal: controller.signal })
      .then(res => {
        if (!res.ok) throw new Error('Could not load weather (check coordinates)');
        return res.json();
      })
      .then(data => { setWeather(data.current); setLoading(false); })
      .catch(err => {
        if (err.name === 'AbortError') return;
        setError(err.message); setLoading(false);
      });

    return () => controller.abort();
  }, [lat, lon]);

  return (
    <div>
      <label>lat <input type="number" value={lat} onChange={e => setLat(e.target.value)} /></label>
      <label> lon <input type="number" value={lon} onChange={e => setLon(e.target.value)} /></label>
      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'crimson' }}>{error}</p>}
      {weather && !loading && !error && (
        <p>{weather.temperature_2m} °C · wind {weather.wind_speed_10m} km/h · code {weather.weather_code}</p>
      )}
    </div>
  );
}
