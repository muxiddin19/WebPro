import { useState, useEffect } from 'react';

function MyComponent() {
  const [data, setData] = useState(null);

  useEffect(() => {
    // Runs after the first render (empty dependency array)
    console.log('Component rendered!');

    // Optional: return a cleanup function
    return () => {
      console.log('Cleanup before next run or unmount');
    };
  }, []);

  return <div>{JSON.stringify(data)}</div>;
}

// Demo wrapper: mount and unmount the component
export default function Demo() {
  const [shown, setShown] = useState(true);
  return (
    <div>
      <button onClick={() => setShown(s => !s)}>{shown ? 'Unmount' : 'Mount'}</button>
      {shown && <MyComponent />}
    </div>
  );
}
