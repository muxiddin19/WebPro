# Week 12 Friday: React Effects, source code

Every file is a complete example from the slides. The default export of each file
is a small runnable demo. All of them run on the live demo page, which uses a
simulated API (no network needed).

| File | Topic |
|---|---|
| 01-EffectSyntax.jsx | useEffect syntax, mount, cleanup |
| 02-DependencyPatterns.jsx | [], [val], and no dependency array |
| 03-UserProfile.jsx | Fetching on mount (loading / error / data) |
| 04-AsyncEffect.jsx | async/await inside an effect |
| 05-LiveClock.jsx | Cleanup of a timer (and a leaky version) |
| 06-AbortFetch.jsx | AbortController cleanup |
| 07-GitHubUserLookup.jsx | Code challenge solution |
| 08-ThemeToggle.jsx | localStorage persistence |
| 09-DocumentTitle.jsx | document.title sync |
| 10-InfiniteLoopGuarded.jsx | Infinite loop and its fix (guarded) |
| 11-DerivedState.jsx | You might not need an effect |
| 12-RaceCondition.jsx | Race condition and abort |
| 13-WeatherStarter.jsx | Homework starter |
