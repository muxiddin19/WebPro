import { useState, useEffect } from 'react';

// Code challenge: one possible solution
export default function GitHubUserLookup() {
  const [input, setInput]       = useState('');
  const [username, setUsername] = useState('');   // set when Search is clicked
  const [user, setUser]         = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState(null);

  useEffect(() => {
    if (!username) return;
    const controller = new AbortController();   // BONUS: abort previous request
    setLoading(true); setError(null); setUser(null);

    fetch(`https://api.github.com/users/${username}`, { signal: controller.signal })
      .then(res => {
        if (res.status === 404) throw new Error('User not found (404)');
        if (!res.ok) throw new Error('Request failed: ' + res.status);
        return res.json();
      })
      .then(data => { setUser(data); setLoading(false); })
      .catch(err => {
        if (err.name === 'AbortError') return;
        setError(err.message); setLoading(false);
      });

    return () => controller.abort();
  }, [username]);

  return (
    <div>
      <input value={input} placeholder="GitHub username"
             onChange={e => setInput(e.target.value)} />
      <button onClick={() => setUsername(input.trim())}>Search</button>

      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'crimson' }}>{error}</p>}
      {user && (
        <div>
          <img src={user.avatar_url} alt="" width="64" height="64" />
          <h3>{user.name || user.login}</h3>
          <p>{user.bio}</p>
          <p>{user.followers} followers · {user.public_repos} public repos</p>
          <a href={user.html_url}>{user.html_url}</a>
        </div>
      )}
    </div>
  );
}
