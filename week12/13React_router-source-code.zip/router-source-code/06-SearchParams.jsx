import { MemoryRouter, useSearchParams, useLocation, useNavigate } from 'react-router-dom';

const products = [
  { id: 1, name: 'React Handbook',   price: 25, date: 20240301 },
  { id: 2, name: 'React Stickers',   price: 4,  date: 20240915 },
  { id: 3, name: 'Router Mug',       price: 12, date: 20241101 },
  { id: 4, name: 'Reactive Poster',  price: 9,  date: 20230105 },
];
const ProductCard = ({ product }) => <li>{product.name} (${product.price})</li>;

function ProductSearch() {
  const [searchParams, setSearchParams] = useSearchParams();
  const query  = searchParams.get('q')    || '';
  const sortBy = searchParams.get('sort') || 'newest';

  const handleSearch = (e) =>
    setSearchParams({ q: e.target.value, sort: sortBy });

  const handleSort = (sort) =>
    setSearchParams({ q: query, sort });

  const filtered = products
    .filter(p => p.name.toLowerCase().includes(query.toLowerCase()))
    .sort((a, b) =>
      sortBy === 'price' ? a.price - b.price : b.date - a.date
    );

  return (
    <div>
      <input value={query} onChange={handleSearch} placeholder="Search products..." />
      <button onClick={() => handleSort('price')}>Sort by Price</button>
      <button onClick={() => handleSort('newest')}>Newest</button>
      <ul>{filtered.map(p => <ProductCard key={p.id} product={p} />)}</ul>
    </div>
  );
}

function BrowserBar() {
  const loc = useLocation();
  const navigate = useNavigate();
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
      <button onClick={() => navigate(-1)}>◀</button>
      <button onClick={() => navigate(1)}>▶</button>
      <code style={{ flex: 1, padding: '4px 8px', border: '1px solid #8886', borderRadius: 6 }}>
        https://my-app.dev{loc.pathname}{loc.search}
      </code>
    </div>
  );
}

export default function Demo() {
  return (<MemoryRouter initialEntries={['/products']}><BrowserBar /><ProductSearch /></MemoryRouter>);
}
