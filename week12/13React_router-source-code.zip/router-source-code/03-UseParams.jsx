import { MemoryRouter, Routes, Route, Link, useParams, useLocation, useNavigate } from 'react-router-dom';

const projects = [
  { id: '1', title: 'Portfolio Site', tech: 'React' },
  { id: '2', title: 'Weather App',    tech: 'React + API' },
  { id: '3', title: 'Todo List',      tech: 'React + useState' },
];

function ProjectDetail() {
  const { id } = useParams(); // reads :id from the URL (always a string)

  const project = projects.find(p => p.id === id);

  if (!project)
    return <p>Not found. <Link to="/projects">Back</Link></p>;

  return (
    <article>
      <h3>{project.title}</h3>
      <p>Tech: {project.tech}</p>
      <p>useParams() returned: {JSON.stringify({ id })}</p>
    </article>
  );
}

function ProjectList() {
  return (
    <ul>
      {projects.map(p => <li key={p.id}><Link to={`/projects/${p.id}`}>{p.title}</Link></li>)}
      <li><Link to="/projects/99">/projects/99 (does not exist)</Link></li>
    </ul>
  );
}

function BrowserBar() {
  const loc = useLocation();
  const navigate = useNavigate();
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
      <button onClick={() => navigate(-1)}>◀</button>
      <button onClick={() => navigate(1)}>▶</button>
      <code style={{ flex: 1, padding: '4px 8px', border: '1px solid #8886', borderRadius: 6 }}>
        https://my-app.dev{loc.pathname}
      </code>
    </div>
  );
}

export default function Demo() {
  return (
    <MemoryRouter initialEntries={['/projects']}>
      <BrowserBar />
      <Routes>
        <Route path="/projects"     element={<ProjectList />} />
        {/* App.jsx: declare the parameterized route */}
        <Route path="/projects/:id" element={<ProjectDetail />} />
      </Routes>
    </MemoryRouter>
  );
}
