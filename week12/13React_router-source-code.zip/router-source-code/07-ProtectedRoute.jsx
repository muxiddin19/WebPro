import { useState } from 'react';
import { MemoryRouter, Routes, Route, Navigate, Outlet, Link, useLocation, useNavigate } from 'react-router-dom';

// ProtectedRoute: redirect to login if not authenticated
function ProtectedRoute({ isAuthenticated }) {
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return <Outlet />;  // render child routes
}

const Login     = () => <p>Login page. (Use the switch above to log in.)</p>;
const Dashboard = () => <h3>Dashboard (private)</h3>;
const Profile   = () => <h3>Profile (private)</h3>;
const Settings  = () => <h3>Settings (private)</h3>;
const NotFound  = () => <h3>404</h3>;

// App.jsx: wrap protected routes
function App({ isAuthenticated }) {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      {/* These routes require authentication */}
      <Route element={<ProtectedRoute isAuthenticated={isAuthenticated} />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/profile"   element={<Profile />} />
        <Route path="/settings"  element={<Settings />} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

function BrowserBar() {
  const loc = useLocation();
  const navigate = useNavigate();
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
      <button onClick={() => navigate(-1)}>◀</button>
      <button onClick={() => navigate(1)}>▶</button>
      <code style={{ flex: 1, padding: '4px 8px', border: '1px solid #8886', borderRadius: 6 }}>
        https://my-app.dev{loc.pathname}
      </code>
    </div>
  );
}

export default function Demo() {
  const [isAuthenticated, setAuth] = useState(false);   // stands in for useAuth()
  return (
    <div>
      <label><input type="checkbox" checked={isAuthenticated} onChange={e => setAuth(e.target.checked)} /> logged in</label>
      <MemoryRouter initialEntries={['/login']}>
        <BrowserBar />
        <nav><Link to="/dashboard">Dashboard</Link> | <Link to="/profile">Profile</Link> | <Link to="/settings">Settings</Link></nav>
        <App isAuthenticated={isAuthenticated} />
      </MemoryRouter>
      <small>Logged out, click a private link: you are redirected to /login (replace: true).</small>
    </div>
  );
}
