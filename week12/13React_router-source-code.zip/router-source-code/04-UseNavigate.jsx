import { useState } from 'react';
import { MemoryRouter, Routes, Route, Link, useNavigate, useLocation, useNavigationType } from 'react-router-dom';

const loginUser = async (email) => { await new Promise(r => setTimeout(r, 400)); return true; };

function LoginForm({ mode }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState('student@gachon.ac.kr');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const success = await loginUser(email, 'secret');

    if (success) {
      if (mode === 'push')    navigate('/dashboard');                      // adds a history entry
      if (mode === 'replace') navigate('/dashboard', { replace: true });   // replaces /login
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input value={email} onChange={e => setEmail(e.target.value)} />
      <button>Log in ({mode})</button>
    </form>
  );
}

function Dashboard() {
  const navigate = useNavigate();
  return (
    <div>
      <h3>Dashboard</h3>
      {/* Go back one page (browser back button equivalent) */}
      <button onClick={() => navigate(-1)}>navigate(-1)</button>
    </div>
  );
}

function BrowserBar() {
  const loc = useLocation();
  const navigate = useNavigate();
  const type = useNavigationType();
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
      <button onClick={() => navigate(-1)}>◀</button>
      <button onClick={() => navigate(1)}>▶</button>
      <code style={{ flex: 1, padding: '4px 8px', border: '1px solid #8886', borderRadius: 6 }}>
        https://my-app.dev{loc.pathname}
      </code>
      <small>last action: {type}</small>
    </div>
  );
}

function Scenario({ mode }) {
  return (
    <MemoryRouter initialEntries={['/']}>
      <BrowserBar />
      <Routes>
        <Route path="/" element={<p>Home. <Link to="/login">Go to login</Link></p>} />
        <Route path="/login" element={<LoginForm mode={mode} />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </MemoryRouter>
  );
}

export default function Demo() {
  const [mode, setMode] = useState('push');
  return (
    <div>
      <label><input type="radio" checked={mode === 'push'} onChange={() => setMode('push')} /> navigate('/dashboard')</label>{' '}
      <label><input type="radio" checked={mode === 'replace'} onChange={() => setMode('replace')} /> navigate('/dashboard', {'{ replace: true }'})</label>
      <p><small>Go to login, submit, then press the browser back button ◀. Where does it land?</small></p>
      <Scenario key={mode} mode={mode} />
    </div>
  );
}
