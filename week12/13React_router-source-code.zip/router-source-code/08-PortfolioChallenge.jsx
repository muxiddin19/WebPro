import { useState } from 'react';
import { MemoryRouter, Routes, Route, NavLink, Link, Outlet, useParams, useNavigate, useLocation } from 'react-router-dom';

// data.js
const projects = [
  { id: '1', title: 'Portfolio Site', tech: 'React',   desc: 'This very app, built with React Router.' },
  { id: '2', title: 'Weather App',    tech: 'API',     desc: 'Fetches the forecast with useEffect.' },
  { id: '3', title: 'Todo List',      tech: 'React',   desc: 'Array state: add, toggle, remove.' },
  { id: '4', title: 'Chat UI',        tech: 'CSS',     desc: 'Flexbox and grid practice.' },
];

// Layout.jsx: NavBar + Footer shared by every page
function Layout() {
  const link = ({ isActive }) => ({ fontWeight: isActive ? 'bold' : 'normal', color: isActive ? '#20B2CC' : 'inherit' });
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <nav style={{ display: 'flex', gap: 12 }}>
        <NavLink to="/" style={link}>Home</NavLink>
        <NavLink to="/about" style={link}>About</NavLink>
        <NavLink to="/projects" style={link}>Projects</NavLink>
      </nav>
      <main><Outlet /></main>
      <footer><small>© Kim Minho, Web Programming K0126_002</small></footer>
    </div>
  );
}

function Home() {
  return (
    <div>
      <h3>Hi, I'm Minho</h3>
      <div style={{ display: 'flex', gap: 12 }}>
        <div><b>{projects.length}</b><br />projects</div>
        <div><b>3</b><br />technologies</div>
        <div><b>1</b><br />year coding</div>
      </div>
    </div>
  );
}

const About = () => (<div><h3>About</h3><p>Computer Engineering student. Skills: HTML, CSS, JavaScript, React.</p></div>);

function Projects() {
  const [tech, setTech] = useState('All');
  const techs = ['All', ...new Set(projects.map(p => p.tech))];
  const shown = projects.filter(p => tech === 'All' || p.tech === tech);
  return (
    <div>
      <h3>Projects</h3>
      <p>{techs.map(t => (
        <button key={t} onClick={() => setTech(t)} style={{ fontWeight: t === tech ? 'bold' : 'normal' }}>{t}</button>
      ))}</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: 8 }}>
        {shown.map(p => (
          <Link key={p.id} to={`/projects/${p.id}`} style={{ border: '1px solid #8886', borderRadius: 8, padding: 8, textDecoration: 'none', color: 'inherit' }}>
            <b>{p.title}</b><br /><small>{p.tech}</small>
          </Link>
        ))}
      </div>
    </div>
  );
}

function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const project = projects.find(p => p.id === id);
  if (!project) return <p>Project not found. <Link to="/projects">All projects</Link></p>;
  return (
    <article>
      <h3>{project.title}</h3>
      <p>{project.desc}</p>
      <p>Tech: {project.tech}</p>
      <button onClick={() => navigate(-1)}>← Back</button>
    </article>
  );
}

const NotFound = () => (<div><h3>404</h3><p>This page does not exist. <Link to="/">Go home</Link></p></div>);

function BrowserBar() {
  const loc = useLocation();
  const navigate = useNavigate();
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
      <button onClick={() => navigate(-1)}>◀</button>
      <button onClick={() => navigate(1)}>▶</button>
      <code style={{ flex: 1, padding: '4px 8px', border: '1px solid #8886', borderRadius: 6 }}>
        https://my-app.dev{loc.pathname}
      </code>
    </div>
  );
}

export default function PortfolioApp() {
  return (
    <MemoryRouter>
      <BrowserBar />
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="about" element={<About />} />
          <Route path="projects" element={<Projects />} />
          <Route path="projects/:id" element={<ProjectDetail />} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </MemoryRouter>
  );
}
