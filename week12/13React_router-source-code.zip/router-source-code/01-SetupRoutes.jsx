import { MemoryRouter, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';

function Home()     { return <h3>Home</h3>; }
function About()    { return <h3>About</h3>; }
function Projects() { return <h3>Projects</h3>; }
function NotFound() { return <h3>404: page not found</h3>; }

// App.jsx: declare your routes
function App() {
  return (
    <Routes>
      <Route path="/"         element={<Home />} />
      <Route path="/about"    element={<About />} />
      <Route path="/projects" element={<Projects />} />
      <Route path="*"         element={<NotFound />} />
    </Routes>
  );
}

// Demo helper: a fake browser address bar
function BrowserBar() {
  const loc = useLocation();
  const navigate = useNavigate();
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
      <button onClick={() => navigate(-1)}>◀</button>
      <button onClick={() => navigate(1)}>▶</button>
      <code style={{ flex: 1, padding: '4px 8px', border: '1px solid #8886', borderRadius: 6 }}>
        https://my-app.dev{loc.pathname}{loc.search}
      </code>
    </div>
  );
}

// Demo wrapper. In a real project main.jsx wraps <App /> in <BrowserRouter>.
export default function Demo() {
  return (
    <MemoryRouter>
      <BrowserBar />
      <nav>
        <Link to="/">Home</Link> | <Link to="/about">About</Link> |{' '}
        <Link to="/projects">Projects</Link> | <Link to="/oops">Broken link</Link>
      </nav>
      <App />
    </MemoryRouter>
  );
}
