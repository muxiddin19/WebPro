import { MemoryRouter, Routes, Route, Outlet, NavLink, Link, useParams, useLocation, useNavigate } from 'react-router-dom';

function Navigation() {
  return (
    <nav style={{ display: 'flex', gap: 12 }}>
      <NavLink to="/">Home</NavLink>
      <NavLink to="/about">About</NavLink>
      <NavLink to="/projects">Projects</NavLink>
    </nav>
  );
}
function Footer() { return <footer><small>© My Portfolio (the footer appears on every page)</small></footer>; }

// Layout.jsx: shared nav + Outlet slot
function Layout() {
  return (
    <div style={{ border: '1px dashed #8886', borderRadius: 8, padding: 8 }}>
      <Navigation />    {/* shown on every page */}
      <main style={{ background: '#2f5d8a22', padding: 8, margin: '8px 0' }}>
        <Outlet />      {/* child route renders here */}
      </main>
      <Footer />
    </div>
  );
}

const Home = () => <h3>Home (index route)</h3>;
const About = () => <h3>About</h3>;
const Projects = () => <div><h3>Projects</h3><Link to="/projects/2">Open project 2</Link></div>;
const ProjectDetail = () => { const { id } = useParams(); return <h3>Project {id}</h3>; };
const NotFound = () => <h3>404</h3>;

// App.jsx: parent route with children
function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index            element={<Home />} />
        <Route path="about"     element={<About />} />
        <Route path="projects"  element={<Projects />} />
        <Route path="projects/:id" element={<ProjectDetail />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

function BrowserBar() {
  const loc = useLocation();
  const navigate = useNavigate();
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
      <button onClick={() => navigate(-1)}>◀</button>
      <button onClick={() => navigate(1)}>▶</button>
      <code style={{ flex: 1, padding: '4px 8px', border: '1px solid #8886', borderRadius: 6 }}>
        https://my-app.dev{loc.pathname}
      </code>
    </div>
  );
}

export default function Demo() {
  return (<MemoryRouter><BrowserBar /><App /></MemoryRouter>);
}
