import { MemoryRouter, Routes, Route, Link, NavLink, useLocation, useNavigate } from 'react-router-dom';

function Navigation() {
  return (
    <nav style={{ display: 'flex', gap: 12 }}>
      {/* Link: basic navigation, no active state */}
      <Link to="/">Home</Link>
      <Link to="/about">About</Link>

      {/* NavLink: adds an 'active' class when the route matches */}
      <NavLink
        to="/projects"
        className={({ isActive }) =>
          isActive ? 'nav-link active' : 'nav-link'
        }
        style={({ isActive }) => ({ fontWeight: isActive ? 'bold' : 'normal' })}
      >
        Projects
      </NavLink>

      {/* NavLink with inline style */}
      <NavLink
        to="/contact"
        style={({ isActive }) =>
          isActive ? { fontWeight: 'bold', color: '#20B2CC' } : {}
        }
      >
        Contact
      </NavLink>
    </nav>
  );
}

function BrowserBar() {
  const loc = useLocation();
  const navigate = useNavigate();
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
      <button onClick={() => navigate(-1)}>◀</button>
      <button onClick={() => navigate(1)}>▶</button>
      <code style={{ flex: 1, padding: '4px 8px', border: '1px solid #8886', borderRadius: 6 }}>
        https://my-app.dev{loc.pathname}
      </code>
    </div>
  );
}

export default function Demo() {
  return (
    <MemoryRouter>
      <BrowserBar />
      <Navigation />
      <Routes>
        <Route path="/"         element={<h3>Home</h3>} />
        <Route path="/about"    element={<h3>About</h3>} />
        <Route path="/projects" element={<h3>Projects</h3>} />
        <Route path="/contact"  element={<h3>Contact</h3>} />
      </Routes>
      <small>Link never highlights; NavLink bolds the page you are on.</small>
    </MemoryRouter>
  );
}
