# Week 13 Friday: React Router, source code

Every file is a complete example from the slides, written against the React Router
v6 API. Each default export is a small runnable demo wrapped in a MemoryRouter
(the live demo page cannot change the browser URL). In your own project, put
`<BrowserRouter>` in main.jsx instead.

React Router v7 is the current major version. Its API for everything in this
lecture is the same; the only change is the import: `from 'react-router'`
instead of `from 'react-router-dom'` (react-router-dom still works).

| File | Topic |
|---|---|
| 01-SetupRoutes.jsx | Routes, Route, path="*" |
| 02-LinkVsNavLink.jsx | Link and NavLink (active styling) |
| 03-UseParams.jsx | /projects/:id and useParams |
| 04-UseNavigate.jsx | useNavigate: push, replace, -1 |
| 05-NestedLayout.jsx | Layout route, Outlet, index route |
| 06-SearchParams.jsx | useSearchParams |
| 07-ProtectedRoute.jsx | ProtectedRoute with Navigate and Outlet |
| 08-PortfolioChallenge.jsx | Code challenge: 4-page portfolio (solution) |
