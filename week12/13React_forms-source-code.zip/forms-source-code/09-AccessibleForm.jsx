import { useState } from 'react';

export default function AccessibleForm() {
  const [email, setEmail]     = useState('');
  const [touched, setTouched] = useState(false);
  const error = touched && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
    ? 'Enter a valid email address' : '';

  return (
    <form noValidate onSubmit={e => { e.preventDefault(); setTouched(true); }}>
      {/* label + htmlFor/id: clicking the label focuses the input */}
      <label htmlFor="email">Email <span aria-hidden="true">(required)</span></label>
      <br />
      <input
        id="email" type="email" value={email}
        onChange={e => setEmail(e.target.value)}
        onBlur={() => setTouched(true)}
        aria-required="true"
        aria-invalid={!!error}                         // marks the invalid field
        aria-describedby={error ? 'email-error' : undefined}   // links the message
      />
      {error && <p id="email-error" role="alert" style={{ color: 'crimson' }}>{error}</p>}
      <p><button>Submit</button></p>
      <p>Test it: click the label, then tab through using only the keyboard.</p>
    </form>
  );
}
