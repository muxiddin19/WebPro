import { useState, useRef } from 'react';

const MAJORS = ['Computer Engineering', 'Software', 'Artificial Intelligence', 'Design'];

// Homework starter: Student Profile Editor
// TODO 1: validate on submit: all required, studentId exactly 10 digits, bio < 200 chars
// TODO 2: on submit, show a "Profile Preview" card with all entered data
// TODO 3: profile photo preview (URL.createObjectURL on the chosen file)
// TODO 4 (stretch): skills as tags: Enter to add, x to remove (array in state)
export default function ProfileEditorStarter() {
  const [form, setForm] = useState({
    name: '', studentId: '', major: MAJORS[0], year: '1', bio: ''
  });
  const fileRef = useRef(null);
  const [fileName, setFileName] = useState('');

  const handleChange = (e) =>
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(form, fileName);   // replace with validation + preview
  };

  return (
    <form onSubmit={handleSubmit}>
      <p><input name="name" value={form.name} onChange={handleChange} placeholder="Name" /></p>
      <p><input name="studentId" value={form.studentId} onChange={handleChange} placeholder="Student ID (10 digits)" /></p>
      <p><select name="major" value={form.major} onChange={handleChange}>
        {MAJORS.map(m => <option key={m}>{m}</option>)}
      </select></p>
      <p>Year: {['1', '2', '3', '4'].map(y => (
        <label key={y}><input type="radio" name="year" value={y}
               checked={form.year === y} onChange={handleChange} /> {y} </label>
      ))}</p>
      <p><textarea name="bio" value={form.bio} onChange={handleChange} rows={3} placeholder="Bio" />
         <br />{form.bio.length} / 200 characters</p>
      <p><input type="file" ref={fileRef} onChange={() => setFileName(fileRef.current.files[0]?.name || '')} />
         {fileName && <span> {fileName}</span>}</p>
      <button>Save profile</button>
    </form>
  );
}
