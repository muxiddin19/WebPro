import { useState } from 'react';

// 1. Mutating state directly: the input looks "stuck"
function MutationBug() {
  const [form, setForm] = useState({ name: '' });
  const handle = (e) => { form.name = e.target.value; setForm(form); };   // WRONG
  return <p><input value={form.name} onChange={handle} placeholder="type: nothing happens" /></p>;
}
function MutationFixed() {
  const [form, setForm] = useState({ name: '' });
  const handle = (e) => setForm(prev => ({ ...prev, name: e.target.value }));   // CORRECT
  return <p><input value={form.name} onChange={handle} placeholder="type: it works" /></p>;
}

// 2. No disabled state: double submits
function SlowForm({ protect }) {
  const [loading, setLoading] = useState(false);
  const [count, setCount]     = useState(0);
  const submit = async (e) => {
    e.preventDefault();
    setCount(c => c + 1);
    setLoading(true);
    await new Promise(r => setTimeout(r, 1500));   // slow network
    setLoading(false);
  };
  return (
    <form onSubmit={submit}>
      <button disabled={protect && loading}>{loading ? 'Sending...' : 'Send'}</button>
      <span> requests sent: {count}</span>
    </form>
  );
}

// 3. Labels: htmlFor + id
function LabelDemo() {
  return (
    <div>
      <p><label>Name (label NOT linked): </label><input id="nolink" /></p>
      <p><label htmlFor="linked">Name (label linked): </label><input id="linked" /></p>
      <small>Click each label: only the linked one focuses its input.</small>
    </div>
  );
}

// 4. Validate on blur, not only on submit
function BlurValidation() {
  const [v, setV] = useState('');
  const [touched, setTouched] = useState(false);
  const err = touched && v.trim() === '' ? 'Required' : '';
  return (
    <p><input value={v} onChange={e => setV(e.target.value)} onBlur={() => setTouched(true)} placeholder="click in, then click out" />
       {err && <span style={{ color: 'crimson' }}> {err}</span>}</p>
  );
}

export default function Demo() {
  return (
    <div>
      <h4>1. Mutating state</h4><MutationBug /><MutationFixed />
      <h4>2. Double submit (click Send twice quickly)</h4><SlowForm protect={false} /><SlowForm protect={true} />
      <h4>3. Label link</h4><LabelDemo />
      <h4>4. Validate on blur</h4><BlurValidation />
    </div>
  );
}
