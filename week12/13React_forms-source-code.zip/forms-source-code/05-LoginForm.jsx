import { useState } from 'react';

export default function LoginForm() {
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus]     = useState('idle'); // idle|loading|success|error

  const handleSubmit = async (e) => {
    e.preventDefault();   // stop the browser's default page reload
    setStatus('loading');
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      if (!res.ok) throw new Error('Invalid credentials');
      setStatus('success');
    } catch (err) { setStatus('error'); }
  };

  return (
    <form onSubmit={handleSubmit}>
      <p>Hint (simulated server): student@gachon.ac.kr / react1234</p>
      <input value={email}    onChange={e => setEmail(e.target.value)}    type="email" placeholder="Email" />
      <input value={password} onChange={e => setPassword(e.target.value)} type="password" placeholder="Password" />
      <button disabled={status === 'loading'}>
        {status === 'loading' ? 'Logging in...' : 'Log In'}
      </button>
      {status === 'error' && <p>Login failed. Check your credentials.</p>}
      {status === 'success' && <p>Welcome back!</p>}
      <p>status = {status}</p>
    </form>
  );
}
