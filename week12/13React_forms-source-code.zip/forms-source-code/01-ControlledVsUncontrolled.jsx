import { useState, useRef } from 'react';

export default function ControlledVsUncontrolled() {
  const [text, setText] = useState('');
  const [read, setRead] = useState('');
  const inputRef = useRef(null);

  return (
    <div>
      <h4>1. Controlled: React state IS the value</h4>
      <input value={text} onChange={e => setText(e.target.value)} placeholder="type here" />
      <p>state = "{text}"</p>

      <h4>2. Controlled but with NO onChange: stuck</h4>
      {/* React warns in the console: value without onChange */}
      <input value="I cannot be edited" />

      <h4>3. Uncontrolled: the DOM owns the value</h4>
      <input ref={inputRef} defaultValue="edit me, then press the button" />
      <button onClick={() => setRead(inputRef.current.value)}>Read value (ref)</button>
      <p>read from the DOM: "{read}"</p>
    </div>
  );
}
