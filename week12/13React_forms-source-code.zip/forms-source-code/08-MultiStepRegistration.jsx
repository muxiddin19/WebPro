import { useState } from 'react';

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Validation is DERIVED from state: no extra state to keep in sync
function validateStep(step, f) {
  const e = {};
  if (step === 1) {
    if (f.name.trim().length < 2) e.name = 'At least 2 characters';
    if (!emailRe.test(f.email))   e.email = 'Enter a valid email address';
  }
  if (step === 2) {
    if (f.username.length < 3 || /\s/.test(f.username)) e.username = 'At least 3 characters, no spaces';
    if (f.password.length < 8)                           e.password = 'At least 8 characters';
    if (!f.confirm || f.confirm !== f.password)          e.confirm  = 'Passwords must match';
  }
  return e;
}

function Field({ label, name, type = 'text', value, onChange, onBlur, error }) {
  const id = 'f-' + name;
  return (
    <p>
      <label htmlFor={id}>{label} </label>
      <input id={id} name={name} type={type} value={value}
             onChange={onChange} onBlur={onBlur}
             aria-invalid={!!error} aria-describedby={error ? id + '-err' : undefined} />
      {error && <span id={id + '-err'} style={{ color: 'crimson' }}> {error}</span>}
    </p>
  );
}

export default function MultiStepRegistration() {
  const [step, setStep]       = useState(1);
  const [done, setDone]       = useState(false);
  const [touched, setTouched] = useState({});
  const [form, setForm] = useState({
    name: '', email: '', username: '', password: '', confirm: '',
    role: 'student', subscribe: false
  });

  const errors = validateStep(step, form);
  const valid  = Object.keys(errors).length === 0;

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };
  const handleBlur = (e) => setTouched(t => ({ ...t, [e.target.name]: true }));
  const shown = (name) => (touched[name] ? errors[name] : undefined);

  const next = () => { if (valid) setStep(s => s + 1); };
  const prev = () => setStep(s => s - 1);      // form data stays in state

  const handleSubmit = (e) => {
    e.preventDefault();
    const { confirm, ...fullFormObject } = form;
    console.log(fullFormObject);
    setDone(true);
  };

  if (done) return <p>Registration submitted. Check the console for the form object.</p>;

  const props = (name) => ({ name, value: form[name], onChange: handleChange, onBlur: handleBlur, error: shown(name) });

  return (
    <form onSubmit={handleSubmit}>
      <p><b>Step {step} of 3</b></p>
      <progress value={step} max="3" />

      {step === 1 && (<>
        <Field label="Name"  {...props('name')} />
        <Field label="Email" type="email" {...props('email')} />
      </>)}

      {step === 2 && (<>
        <Field label="Username" {...props('username')} />
        <Field label="Password" type="password" {...props('password')} />
        <Field label="Confirm password" type="password" {...props('confirm')} />
      </>)}

      {step === 3 && (<>
        <p>
          {['student', 'ta', 'instructor'].map(r => (
            <label key={r}>
              <input type="radio" name="role" value={r} checked={form.role === r} onChange={handleChange} /> {r}{' '}
            </label>
          ))}
        </p>
        <label><input type="checkbox" name="subscribe" checked={form.subscribe} onChange={handleChange} /> Subscribe to newsletter</label>
        <h4>Review</h4>
        <ul>
          <li>Name: {form.name}</li><li>Email: {form.email}</li><li>Username: {form.username}</li>
          <li>Password: {'*'.repeat(form.password.length)}</li><li>Role: {form.role}</li>
          <li>Newsletter: {form.subscribe ? 'yes' : 'no'}</li>
        </ul>
      </>)}

      <p>
        {step > 1 && <button type="button" onClick={prev}>Previous</button>}
        {step < 3 && <button type="button" onClick={next} disabled={!valid}>Next</button>}
        {step === 3 && <button>Submit</button>}
      </p>
    </form>
  );
}
