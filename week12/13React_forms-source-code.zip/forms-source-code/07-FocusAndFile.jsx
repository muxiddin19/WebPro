import { useState, useRef } from 'react';

function SearchFocus() {
  const inputRef = useRef(null);

  const handleFocus = () => {
    inputRef.current.focus();    // focus the DOM element
    inputRef.current.select();   // also select existing text
  };

  return (
    <div>
      <input ref={inputRef} type="text" defaultValue="select me" />
      <button onClick={handleFocus}>Focus Search</button>
    </div>
  );
}

// File inputs MUST use useRef (they cannot be controlled)
function FileUpload() {
  const fileRef = useRef(null);
  const [info, setInfo] = useState('no file chosen');

  const handleUpload = () => {
    const file = fileRef.current.files[0];
    console.log(file.name, file.size, file.type);
    setInfo(file.name + ' · ' + file.size + ' bytes · ' + (file.type || 'unknown type'));
  };
  return (
    <div>
      <input type="file" ref={fileRef} onChange={handleUpload} />
      <p>{info}</p>
    </div>
  );
}

export default function Demo() {
  return (<div><h4>Focus management</h4><SearchFocus /><h4>File input</h4><FileUpload /></div>);
}
