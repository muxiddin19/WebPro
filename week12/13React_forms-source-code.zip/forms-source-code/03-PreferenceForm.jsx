import { useState } from 'react';

export default function PreferenceForm() {
  const [country, setCountry] = useState('KR');
  const [bio, setBio]         = useState('');
  const [agree, setAgree]     = useState(false);
  const [plan, setPlan]       = useState('free');

  return (
    <form>
      {/* Select: value on <select>, NOT on <option> */}
      <select value={country} onChange={e => setCountry(e.target.value)}>
        <option value="KR">South Korea</option>
        <option value="UZ">Uzbekistan</option>
        <option value="US">United States</option>
      </select>

      {/* Textarea: same pattern as <input> */}
      <p><textarea value={bio} onChange={e => setBio(e.target.value)} rows={3} /></p>

      {/* Checkbox: use checked, not value */}
      <label>
        <input type="checkbox" checked={agree}
               onChange={e => setAgree(e.target.checked)} /> I agree
      </label>

      {/* Radio: checked is true for the input whose value === state */}
      <p>
        <label><input type="radio" value="free" checked={plan === 'free'}
                      onChange={e => setPlan(e.target.value)} /> Free</label>
        <label><input type="radio" value="pro" checked={plan === 'pro'}
                      onChange={e => setPlan(e.target.value)} /> Pro</label>
      </p>

      <pre>{JSON.stringify({ country, bio, agree, plan }, null, 2)}</pre>
    </form>
  );
}
