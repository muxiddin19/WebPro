import { useState } from 'react';

export default function RegistrationForm() {
  const [form, setForm] = useState({
    name: '', email: '', password: '', role: 'student', subscribe: false
  });

  // One handler for ALL fields: reads e.target.name
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value   // computed key
    }));
  };

  return (
    <form>
      <input name="name"     value={form.name}     onChange={handleChange} placeholder="Name" />
      <input name="email"    value={form.email}    onChange={handleChange} type="email" placeholder="Email" />
      <input name="password" value={form.password} onChange={handleChange} type="password" placeholder="Password" />
      <select name="role"    value={form.role}     onChange={handleChange}>
        <option value="student">Student</option>
        <option value="ta">Teaching Assistant</option>
      </select>
      {/* extra: shows the type === 'checkbox' branch */}
      <label>
        <input name="subscribe" type="checkbox" checked={form.subscribe} onChange={handleChange} /> Newsletter
      </label>
      <pre>{JSON.stringify(form, null, 2)}</pre>
    </form>
  );
}
