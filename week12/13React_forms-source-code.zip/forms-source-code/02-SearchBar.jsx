import { useState } from 'react';

export default function SearchBar() {
  const [query, setQuery] = useState('');

  return (
    <div>
      <input
        type="text"
        value={query}                              // React controls value
        onChange={e => setQuery(e.target.value)}   // update state on change
        placeholder="Search..."
      />
      <p>Searching for: "{query}"</p>

      {/* Real-time character count: only possible with a controlled input */}
      <span>{query.length} / 100 characters</span>

      {/* Clear programmatically */}
      <button onClick={() => setQuery('')}>Clear</button>
    </div>
  );
}
