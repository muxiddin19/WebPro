import { useState } from 'react';

export default function RegisterForm() {
  const [form, setForm]     = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [done, setDone]     = useState(false);

  const handleChange = (e) =>
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const validate = () => {
    const errs = {};
    if (!form.name.trim())
      errs.name = 'Name is required';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      errs.email = 'Enter a valid email address';
    if (form.password.length < 8)
      errs.password = 'Password must be at least 8 characters';
    return errs;    // empty object = all valid
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setErrors({});          // clear errors on a successful resubmit
    setDone(true);          // all valid: proceed with submission
  };

  if (done) return <p>Registered: {form.name} ({form.email})</p>;

  return (
    <form onSubmit={handleSubmit} noValidate>
      <p><input name="name" value={form.name} onChange={handleChange} placeholder="Name" />
         {errors.name && <span style={{ color: 'crimson' }}> {errors.name}</span>}</p>
      <p><input name="email" value={form.email} onChange={handleChange} placeholder="Email" />
         {errors.email && <span style={{ color: 'crimson' }}> {errors.email}</span>}</p>
      <p><input name="password" type="password" value={form.password} onChange={handleChange} placeholder="Password" />
         {errors.password && <span style={{ color: 'crimson' }}> {errors.password}</span>}</p>
      <button>Register</button>
    </form>
  );
}
